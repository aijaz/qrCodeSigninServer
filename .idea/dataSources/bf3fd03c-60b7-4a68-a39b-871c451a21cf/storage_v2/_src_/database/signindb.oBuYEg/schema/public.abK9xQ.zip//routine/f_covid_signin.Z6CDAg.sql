create function f_covid_signin(p_dt timestamp with time zone, p_name character varying, p_phone character varying, p_email character varying, p_key character varying) returns text
    language plpgsql
as
$$
BEGIN
        INSERT INTO covid_signin_sheet(dt
    , name
    , phone
    , email
    )
    values (p_dt
    , pgp_sym_encrypt(p_name, p_key)
    , pgp_sym_encrypt(p_phone, p_key)
    , pgp_sym_encrypt(p_email, p_key)
    );
    return '1';
end;
$$;

alter function f_covid_signin(timestamp with time zone, varchar, varchar, varchar, varchar) owner to signin;

