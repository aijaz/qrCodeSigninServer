create function f_change_password_forgot(p_guid character varying, p_password character varying)
    returns TABLE(team_member_id integer, email character varying)
    language plpgsql
as
$$
DECLARE
  v_email varchar := '';
  v_team_member_id INTEGER;
BEGIN
  SELECT forgot_message.team_member_id INTO v_team_member_id FROM forgot_message WHERE guid = p_guid AND date_validated IS NULL;
  IF NOT FOUND THEN
    RETURN;
  END IF;
  SELECT team_member.email INTO v_email FROM team_member WHERE id = v_team_member_id;
  DELETE FROM team_member_auth_token WHERE team_member_auth_token.team_member_id = v_team_member_id;
  UPDATE team_member SET password = crypt(p_password, gen_salt('bf', 10)) WHERE id = v_team_member_id;
  UPDATE forgot_message SET date_validated = statement_timestamp() WHERE guid = p_guid;
  RETURN QUERY SELECT v_team_member_id, v_email;
END;
$$;

alter function f_change_password_forgot(varchar, varchar) owner to signin;

