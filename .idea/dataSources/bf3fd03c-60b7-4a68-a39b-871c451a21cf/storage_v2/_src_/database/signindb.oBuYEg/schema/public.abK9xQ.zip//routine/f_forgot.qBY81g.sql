create function f_forgot(p_email character varying)
    returns TABLE(guid character varying)
    language plpgsql
as
$$
DECLARE
  guid VARCHAR := '';
  arow RECORD;
  v_team_member_id INTEGER;
BEGIN
  SELECT p.id INTO v_team_member_id FROM team_member p WHERE p.email = p_email;
  IF NOT FOUND THEN
    RETURN;
  END IF;
  SELECT gen_random_uuid() INTO guid;
  DELETE FROM forgot_message f WHERE f.team_member_id = v_team_member_id;
  INSERT INTO forgot_message(guid, team_member_id) VALUES (guid, v_team_member_id);
  RETURN QUERY SELECT guid;
END;
$$;

alter function f_forgot(varchar) owner to signin;

