create function random_string(length integer) returns text
    language plpgsql
as
$$
declare
  chars TEXT[] := '{0,1,2,3,4,5,6,7,8,9,B,C,D,F,G,H,J,K,L,M,N,P,Q,R,S,T,V,W,X,Z,b,c,d,f,g,h,j,k,l,m,n,p,q,r,s,t,v,w,x,z}';
  result TEXT := '';
  i INTEGER := 0;
begin
  IF length < 0 THEN
    RAISE exception 'Given length cannot be less than 0';
  END IF;
  FOR i IN 1..length LOOP
    result := result || chars[1+random()*(array_length(chars, 1)-1)];
  END LOOP;
  RETURN result;
END;
$$;

alter function random_string(integer) owner to signin;

