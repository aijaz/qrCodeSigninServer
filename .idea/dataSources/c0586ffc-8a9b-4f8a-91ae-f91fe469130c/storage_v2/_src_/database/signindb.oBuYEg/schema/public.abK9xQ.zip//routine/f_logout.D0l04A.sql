create function f_logout(p_token character varying) returns integer
    language plpgsql
as
$$
BEGIN
    DELETE FROM team_member_auth_token WHERE token = crypt(p_token, token);
    RETURN 1;
END;
$$;

alter function f_logout(varchar) owner to signin;

