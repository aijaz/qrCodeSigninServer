create function f_auth(p_token character varying)
    returns TABLE(id integer, name character varying)
    language plpgsql
as
$$
DECLARE
    arow RECORD;
BEGIN
    SELECT team_member_id INTO arow FROM team_member_auth_token WHERE token = crypt(p_token, token);
    IF NOT FOUND THEN
        RETURN;
    END IF;
    -- we're good
    -- update last update
    UPDATE team_member_auth_token SET last_use_date = statement_timestamp() WHERE token = p_token;
    RETURN QUERY SELECT p.id, p.name FROM team_member p WHERE p.id = arow.team_member_id;
END;
$$;

alter function f_auth(varchar) owner to signin;

