create function install_print_guid_message(p_email text) returns text
    language plpgsql
as
$$
DECLARE
  output  text;
BEGIN

PERFORM * FROM f_forgot(p_email);
UPDATE forgot_message set guid = random_string(8);

select into output 
chr(10)
|| chr(10)
|| 'This is your password recovery code: ' || guid 
|| chr(10)
|| chr(10)
|| 'Please save this so that you can set your password.         '
|| chr(10)
|| chr(10)
|| chr(10)
from forgot_message limit 1;
  /* Return the output text variable. */
  RETURN output;
END
$$;

alter function install_print_guid_message(text) owner to signin;

