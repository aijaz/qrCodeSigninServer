create function f_add_team_member(p_email text, p_admin boolean, p_name text, p_read_only boolean)
    returns TABLE(guid text)
    language plpgsql
as
$$
BEGIN
        insert into team_member(
                        email
                      , password
                      , admin
                      , name
                      , read_only)
                      values (
                                p_email
                              , ''
                              , p_admin
                              , p_name
                              , p_read_only
                             );
        RETURN QUERY SELECT * FROM f_forgot(p_email);

    end;
$$;

alter function f_add_team_member(text, boolean, text, boolean) owner to signin;

