create function f_login(p_email character varying, p_password character varying, p_auth_type t_auth_type)
    returns TABLE(token character varying, login_id integer, name character varying, admin boolean, read_only boolean)
    language plpgsql
as
$$
DECLARE
  token VARCHAR := '';
  arow RECORD;
  crypted_token VARCHAR;
BEGIN
  SELECT t.id, t.name, t.admin, t.read_only INTO arow
  FROM team_member t
  WHERE email = p_email
  AND password=crypt(p_password, password);
  IF NOT FOUND THEN
    RETURN;
  END IF;
  -- successful login
  SELECT gen_random_uuid() INTO token;
  SELECT crypt(token, gen_salt('bf')) INTO crypted_token;
  INSERT INTO team_member_auth_token (team_member_id, token, auth_type) VALUES (arow.id, crypted_token, p_auth_type);
  RETURN QUERY SELECT token, arow.id, arow.name, arow.admin, arow.read_only;
END;
$$;

alter function f_login(varchar, varchar, t_auth_type) owner to signin;

