create function f_change_password(p_team_member_id integer, p_old_password character varying, p_new_password character varying)
    returns TABLE(result integer)
    language plpgsql
as
$$
DECLARE
  arow RECORD;
  v_email_id INTEGER;
  v_team_member_id INTEGER;
BEGIN
  PERFORM id FROM team_member WHERE id = p_team_member_id AND password=crypt(p_old_password, password);
  IF NOT FOUND THEN
    RETURN;
  END IF;
  UPDATE team_member SET password = crypt(p_new_password, gen_salt('bf', 10)) WHERE id = p_team_member_id;
  RETURN QUERY SELECT 1;
END;
$$;

alter function f_change_password(integer, varchar, varchar) owner to signin;

